import React from "react";
import { CiSearch } from "react-icons/ci";
import { FiShoppingCart } from "react-icons/fi";
import { TbLogin2 } from "react-icons/tb";
import "./Navbar.css"
import { NavLink } from "react-router-dom";

function Navbar() {
  return (
    <>
      <nav>
        <div className="container">
          <div className="nav-img">
            <img src="/public/imgs/logo.svg" alt="" />
          </div>

          <ul className="links">
            <li>
              <NavLink to={"/"}>Home</NavLink>
            </li>
            <li>
              {" "}
              <NavLink to={"/shop"}>Shop</NavLink>
            </li>
            <li>
              {" "}
              <NavLink to={"/plan"}>Plant Care</NavLink>
            </li>
            <li>
              {" "}
              <NavLink to={"/blog"}>Blogs</NavLink>
            </li>
          </ul>

          <div className="elements">
            <CiSearch className="search" />
            <div className="shopes">
                 <FiShoppingCart className="shopingBags"/>
            <div className="count">0</div>
            </div>
            <span>
                <TbLogin2 />
                <p>Login</p>
            </span>
          </div>
        </div>
      </nav>
    </>
  );
}

export default Navbar;
