import React from "react";
import Cards from "../../components/cards/Cards";

function Search({ homeData}) {
  return (
    <>
      <section>
        <div className="container">
          <div className="cards">
            
            <Cards homeData={homeData} />
          </div>
        </div>
      </section>
    </>
  );
}

export default Search;
