import React from 'react'

function Error() {
  return (
    <>
    
        <section className='errorJs'>
            <div className="container">
                <img src="https://tint.creativemarket.com/vVEKgXGRxVb3dZ6B_igQEaXAEAFiN2DvRSH9rrz3-mc/width:1200/height:800/gravity:nowe/rt:fill-down/el:1/czM6Ly9maWxlcy5jcmVhdGl2ZW1hcmtldC5jb20vaW1hZ2VzL3NjcmVlbnNob3RzL3Byb2R1Y3RzLzg1My84NTMzLzg1MzM4MjEvbmV3X2NhdF9ib3hfJUQxJTgxJUQwJUJBJUQxJTgwJUQwJUI4JUQwJUJELW8uanBn?1592234602" alt="" />
            </div>
        </section>

    </>
  )
}

export default Error