import { useState } from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "./components/navbar/Navbar";
import Footer from "./components/footer/Footer";
import Home from "./pages/home/Home";
import Error from "./pages/error/Error";

function App() {
  const [footerData, setFooterData] = useState([
    {
      id: 0,
      img: "/imgs/foter1.png",
      title: "Garden Care",
      info: "We are an online plant shop offering a wide range of cheap and trendy plants.",
    },

    {
      id: 0,
      img: "/imgs/foter2.png",
      title: "Plant Renovation",
      info: "We are an online plant shop offering a wide range of cheap and trendy plants.",
    },

    {
      id: 0,
      img: "/imgs/foter3.png",
      title: "Watering Graden",
      info: "We are an online plant shop offering a wide range of cheap and trendy plants.",
    },
  ]);

  const [homeData, setHomeData] = useState([
    {
      id: Math.floor(Math.random()*99999),
      img:"/imgs/card1.png",
      title: "Barberton Daisy",
      price:"$119.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card2.png",
      title: "Angel Wing Begonia",
      price:"$169.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card3.png",
      title: "African Violet",
      price:"$199.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card4.png",
      title: "Beach Spider Lily",
      price:"$129.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card5.png",
      title: "Blushing Bromeliad",
      price:"$139.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card6.png",
      title: "Aluminum Plant",
      price:"$179.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card7.png",
      title: "Bird's Nest Fern",
      price:"$99.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card8.png",
      title: "Broadleaf Lady Palm",
      price:"$59.00",

    },

    {
      id:Math.floor(Math.random()*99999),
      img:"/imgs/card9.png",
      title: "Chinese Evergreen",
      price:"$39.00",

    },
  ])

  return (
    <>
      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path="/" element={<Home homeData={homeData} element={<Home/>} />} />
          <Route path="*" element={<Error />} />
        </Routes>

        <Footer footerData={footerData} />
      </BrowserRouter>
    </>
  );
}

export default App;
