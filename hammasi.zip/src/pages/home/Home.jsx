import React from "react";
import "./Home.css";
import { NavLink } from "react-router-dom";
import { FaAngleDown, FaAngleRight } from "react-icons/fa";
import Cards from "../../components/cards/Cards";

function Home({homeData}) {
  return (
    <>
      <div className="homeHero">
        <div className="container">
          <div className="homeHero-left">
            <h4>Welcome to GreenShop</h4>
            <h1>
              Let’s Make a Better <span>Planet</span>
            </h1>
            <p>
              We are an online plant shop offering a wide range of cheap and
              trendy plants. Use our plants to create an unique Urban Jungle.
              Order your favorite plants!
            </p>
            <button>SHOP NOW</button>
          </div>

          <div className="homeHero-right">
            <img src="/imgs/homehero.png" alt="" />
          </div>
        </div>
      </div>

      <section className="">
        <div className="container">
          <div className="prodact-title">
            <ul>
              <li>
                <NavLink>All Plants</NavLink>
              </li>
              <li>
                <NavLink>New Arrivals</NavLink>
              </li>
              <li>
                <NavLink>Sale</NavLink>
              </li>
            </ul>

            <span>
              <p>Short by:</p>
              <p>Default sorting</p>
              <p>
                <FaAngleDown />
              </p>
            </span>
          </div>

          <div className="asos">
            <div className="catigory-left">
            <h3>Categories</h3>

            <div className="menus">
              <span>
                <p>House Plants</p>
                <p>(33)</p>
              </span>
              <span>
                <p>Potter Plants</p>
                <p>(12)</p>
              </span>
              <span>
                <p>Seeds</p>
                <p>(65)</p>
              </span>
              <span>
                <p>Small Plants</p>
                <p>(39)</p>
              </span>
              <span>
                <p>Big Plants</p>
                <p>(23)</p>
              </span>
              <span>
                <p>Succulents</p>
                <p>(17)</p>
              </span>

              <span>
                <p>Trerrariums</p>
                <p>(19)</p>
              </span>

              <span>
                <p>Gardening</p>
                <p>(13)</p>
              </span>
              <span>
                <p>Accessories</p>
                <p>(18)</p>
              </span>
            </div>

            <div className="priceRange">
              <h3>Price Range</h3>
              <div className="lines">
                <div className="line1"></div>
                <div className="line2"></div>
              </div>

              <p className="pric">
                Price: <p> $39 - $1230</p>
              </p>
              <button>Filter</button>
            </div>

            <div className="size">
              <h3>Size</h3>
              <span>
                <p>Small</p>
                <p>(119)</p>
              </span>

              <span>
                <p>Medium</p>
                <p>(86)</p>
              </span>
              <span>
                <p>Large</p>
                <p>(78)</p>
              </span>
            </div>

            <div className="left-img">
              <img src="/imgs/left.png" alt="" />
            </div>
          </div>
          <div className="catigory-right">

            <Cards data={homeData}/>

            <div className="bolim">
              <span>1</span>
              <span>2</span>
              <span>3</span>
              <span>4</span>
              <span><FaAngleRight /></span>
            </div>
          </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;
